public interface Invoice 
{
    public String createInvoice(int purchased);
}